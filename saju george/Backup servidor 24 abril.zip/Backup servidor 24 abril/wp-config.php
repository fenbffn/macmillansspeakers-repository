<?php
/**
 * The base configurations of the WordPress.
 *
 * This file has the following configurations: MySQL settings, Table Prefix,
 * Secret Keys, WordPress Language, and ABSPATH. You can find more information
 * by visiting {@link http://codex.wordpress.org/Editing_wp-config.php Editing
 * wp-config.php} Codex page. You can get the MySQL settings from your web host.
 *
 * This file is used by the wp-config.php creation script during the
 * installation. You don't have to use the web site, you can just copy this file
 * to "wp-config.php" and fill in the values.
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define('DB_NAME', 'macmillanspeaker');

/** MySQL database username */
define('DB_USER', 'macmillanspeaker');

/** MySQL database password */
define('DB_PASSWORD', 'yxm7jlOyQ48o2tr');

/** MySQL hostname */
define('DB_HOST', 'localhost');

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         '4q;EDdkS* =iXj.:ywa89JBMls`Rb#Y^}%Swf[rblmb:xk+2-GU:Kk_DT_OK`Y^e');
define('SECURE_AUTH_KEY',  'rao|]A3pbfsX)}GQrNxp dDD5Xi$e/ydJ/OcC::?;f22PY2mYj~QnFk2OOhn0j=0');
define('LOGGED_IN_KEY',    '0xU;4VN`ZkV4undp0:sW)Z[x5J]@!z&vTk=NTwBgU<B#-3:J.u SN%sb?mHB(b)6');
define('NONCE_KEY',        '[,`zUHKyX)XG58If]x?zd3xrvo|9A{LP$awyw<.ZL6406+r,TK#dpnDAC]Q]g=Hf');
define('AUTH_SALT',        '1aYG#d#l TH2),(4@J ykgAfL[zT-3M=,H`toX5Z/aJ~9)M:=VZ-6Bdg-}Lqwu+l');
define('SECURE_AUTH_SALT', 'B92Hy{c06Hqx/?2oqHP81b72tIsc{B;.2N5uP:i{d1P.E&<n<^0_iA}~bZw*O*: ');
define('LOGGED_IN_SALT',   'RMFnX`gKbM:M)-3iRKGyW2Aa_g{g~j3;<`>zkA id<0/H6N*obk,T,UOBz,H#F0*');
define('NONCE_SALT',       '^pK{r5Pz%R@-j(#=o(!KP{Zl J`))I})| _nJ@F/&n5P:nzriu;bv}a$@0DP3Zun');

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each a unique
 * prefix. Only numbers, letters, and underscores please!
 */
$table_prefix  = 'mc_';

/**
 * WordPress Localized Language, defaults to English.
 *
 * Change this to localize WordPress. A corresponding MO file for the chosen
 * language must be installed to wp-content/languages. For example, install
 * de_DE.mo to wp-content/languages and set WPLANG to 'de_DE' to enable German
 * language support.
 */
define('WPLANG', '');

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 */
define('WP_DEBUG', false);

/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');
